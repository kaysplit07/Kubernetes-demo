## Using Google Cloud SQL from a WordPress Deployment

[![Open in Cloud Shell](https://gstatic.com/cloudssh/images/open-btn.svg)](https://ssh.cloud.google.com/cloudshell/editor?cloudshell_git_repo=https://github.com/GoogleCloudPlatform/kubernetes-engine-samples&cloudshell_tutorial=README.md&cloudshell_workspace=cloudsql/)

Follow this tutorial at https://cloud.google.com/kubernetes-engine/docs/tutorials/persistent-disk/

Content for this tutorial has been moved to [/wordpress-persistent-disks](https://github.com/GoogleCloudPlatform/kubernetes-engine-samples/tree/master/wordpress-persistent-disks)
